import { Injectable, signal } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';

export interface User {
  id: number;
  name: string;
  email: string;
}

@Injectable({
  providedIn: 'root'
})
export class SimpleHttpService {
  private baseUrl = 'https://api.example.com';
  
  // Signals para estado
  private loadingSignal = signal(false);
  private errorSignal = signal<string | null>(null);
  
  // Public readonly signals
  readonly isLoading = this.loadingSignal.asReadonly();
  readonly error = this.errorSignal.asReadonly();
  
  constructor(private http: HttpClient) {}
  
  /**
   * GET request simples
   */
  getUsers(): Observable<User[]> {
    this.setLoading(true);
    this.clearError();
    
    return this.http.get<User[]>(`${this.baseUrl}/users`).pipe(
      tap(() => {
        this.setLoading(false);
      }),
      catchError(error => this.handleError(error))
    );
  }
  
  /**
   * GET com parâmetros
   */
  getUserById(id: number): Observable<User> {
    this.setLoading(true);
    this.clearError();
    
    return this.http.get<User>(`${this.baseUrl}/users/${id}`).pipe(
      tap(() => {
        this.setLoading(false);
      }),
      catchError(error => this.handleError(error))
    );
  }
  
  /**
   * POST request
   */
  createUser(user: Omit<User, 'id'>): Observable<User> {
    this.setLoading(true);
    this.clearError();
    
    return this.http.post<User>(`${this.baseUrl}/users`, user).pipe(
      tap(() => {
        this.setLoading(false);
      }),
      catchError(error => this.handleError(error))
    );
  }
  
  /**
   * PUT request
   */
  updateUser(id: number, user: Partial<User>): Observable<User> {
    this.setLoading(true);
    this.clearError();
    
    return this.http.put<User>(`${this.baseUrl}/users/${id}`, user).pipe(
      tap(() => {
        this.setLoading(false);
      }),
      catchError(error => this.handleError(error))
    );
  }
  
  /**
   * DELETE request
   */
  deleteUser(id: number): Observable<void> {
    this.setLoading(true);
    this.clearError();
    
    return this.http.delete<void>(`${this.baseUrl}/users/${id}`).pipe(
      tap(() => {
        this.setLoading(false);
      }),
      catchError(error => this.handleError(error))
    );
  }
  
  /**
   * GET com query parameters
   */
  searchUsers(query: string): Observable<User[]> {
    this.setLoading(true);
    this.clearError();
    
    const params = new HttpParams().set('q', query);
    
    return this.http.get<User[]>(`${this.baseUrl}/users/search`, { params }).pipe(
      tap(() => {
        this.setLoading(false);
      }),
      catchError(error => this.handleError(error))
    );
  }
  
  /**
   * Limpa erro
   */
  clearError(): void {
    this.errorSignal.set(null);
  }
  
  /**
   * Reseta estado
   */
  reset(): void {
    this.setLoading(false);
    this.clearError();
  }
  
  // Private methods
  
  private setLoading(loading: boolean): void {
    this.loadingSignal.set(loading);
  }
  
  private handleError(error: any): Observable<never> {
    this.setLoading(false);
    this.errorSignal.set('Erro na requisição');
    return throwError(() => error);
  }
}
