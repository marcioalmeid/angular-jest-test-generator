/**
 * Exemplo de como testar HttpClient com mocks
 * 
 * Este arquivo demonstra as melhores práticas para testar
 * serviços que usam HttpClient com mocks adequados.
 */

import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { HttpClientService, ApiResponse, User, CreateUserRequest } from './http-client.service';
import { HttpErrorResponse } from '@angular/common/http';

describe('HttpClientService - Exemplo com Mocks', () => {
  let service: HttpClientService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [HttpClientService]
    });
    
    service = TestBed.inject(HttpClientService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    // Verifica se não há requests pendentes
    httpMock.verify();
  });

  describe('GET Requests', () => {
    it('deve fazer GET request e retornar dados', (done) => {
      // Arrange
      const mockResponse: ApiResponse<User[]> = {
        data: [
          { id: 1, name: 'John Doe', email: 'john@test.com', role: 'user', active: true, createdAt: new Date() }
        ],
        status: 200,
        message: 'Success',
        timestamp: Date.now()
      };

      // Act
      service.getUsers(1, 10).subscribe(response => {
        // Assert
        expect(response).toEqual(mockResponse);
        expect(response.data.users).toHaveLength(1);
        expect(response.data.users[0].name).toBe('John Doe');
        done();
      });

      // Mock da requisição HTTP
      const req = httpMock.expectOne('https://api.example.com/users?page=1&pageSize=10');
      expect(req.request.method).toBe('GET');
      expect(req.request.headers.get('Authorization')).toBe('Bearer your-api-key');
      expect(req.request.headers.get('Content-Type')).toBe('application/json');
      
      // Simula resposta
      req.flush(mockResponse);
    });

    it('deve fazer GET com parâmetros customizados', (done) => {
      // Arrange
      const params = { search: 'john', active: 'true' };
      const mockResponse: ApiResponse<User[]> = {
        data: [],
        status: 200,
        message: 'Success',
        timestamp: Date.now()
      };

      // Act
      service.searchUsers(params).subscribe(response => {
        expect(response).toEqual(mockResponse);
        done();
      });

      // Assert
      const req = httpMock.expectOne('https://api.example.com/users/search?search=john&active=true');
      expect(req.request.method).toBe('GET');
      req.flush(mockResponse);
    });
  });

  describe('POST Requests', () => {
    it('deve criar usuário com POST', (done) => {
      // Arrange
      const newUser: CreateUserRequest = {
        name: 'Jane Doe',
        email: 'jane@test.com',
        role: 'user'
      };
      
      const mockResponse: ApiResponse<User> = {
        data: {
          id: 2,
          name: 'Jane Doe',
          email: 'jane@test.com',
          role: 'user',
          active: true,
          createdAt: new Date()
        },
        status: 201,
        message: 'Created',
        timestamp: Date.now()
      };

      // Act
      service.createUser(newUser).subscribe(response => {
        // Assert
        expect(response.status).toBe(201);
        expect(response.data.name).toBe('Jane Doe');
        expect(response.data.id).toBe(2);
        done();
      });

      // Mock da requisição
      const req = httpMock.expectOne('https://api.example.com/users');
      expect(req.request.method).toBe('POST');
      expect(req.request.body).toEqual(newUser);
      req.flush(mockResponse);
    });
  });

  describe('PUT Requests', () => {
    it('deve atualizar usuário com PUT', (done) => {
      // Arrange
      const userId = 1;
      const updateData = { name: 'John Updated', email: 'john.updated@test.com' };
      const mockResponse: ApiResponse<User> = {
        data: {
          id: 1,
          name: 'John Updated',
          email: 'john.updated@test.com',
          role: 'user',
          active: true,
          createdAt: new Date()
        },
        status: 200,
        message: 'Updated',
        timestamp: Date.now()
      };

      // Act
      service.updateUser(userId, updateData).subscribe(response => {
        // Assert
        expect(response.data.name).toBe('John Updated');
        expect(response.data.email).toBe('john.updated@test.com');
        done();
      });

      // Mock da requisição
      const req = httpMock.expectOne(`https://api.example.com/users/${userId}`);
      expect(req.request.method).toBe('PUT');
      expect(req.request.body).toEqual(updateData);
      req.flush(mockResponse);
    });
  });

  describe('PATCH Requests', () => {
    it('deve fazer PATCH parcial', (done) => {
      // Arrange
      const userId = 1;
      const patchData = { active: false };
      const mockResponse: ApiResponse<User> = {
        data: {
          id: 1,
          name: 'John Doe',
          email: 'john@test.com',
          role: 'user',
          active: false,
          createdAt: new Date()
        },
        status: 200,
        message: 'Updated',
        timestamp: Date.now()
      };

      // Act
      service.patchUser(userId, patchData).subscribe(response => {
        // Assert
        expect(response.data.active).toBe(false);
        done();
      });

      // Mock da requisição
      const req = httpMock.expectOne(`https://api.example.com/users/${userId}`);
      expect(req.request.method).toBe('PATCH');
      expect(req.request.body).toEqual(patchData);
      req.flush(mockResponse);
    });
  });

  describe('DELETE Requests', () => {
    it('deve deletar usuário', (done) => {
      // Arrange
      const userId = 1;
      const mockResponse: ApiResponse<void> = {
        data: undefined as any,
        status: 204,
        message: 'Deleted',
        timestamp: Date.now()
      };

      // Act
      service.deleteUser(userId).subscribe(response => {
        // Assert
        expect(response.status).toBe(204);
        expect(response.message).toBe('Deleted');
        done();
      });

      // Mock da requisição
      const req = httpMock.expectOne(`https://api.example.com/users/${userId}`);
      expect(req.request.method).toBe('DELETE');
      req.flush(mockResponse);
    });
  });

  describe('File Upload', () => {
    it('deve fazer upload de arquivo', (done) => {
      // Arrange
      const userId = 1;
      const file = new File(['test content'], 'avatar.jpg', { type: 'image/jpeg' });
      const additionalData = { description: 'Profile avatar' };
      
      const mockResponse: ApiResponse<{ avatarUrl: string }> = {
        data: { avatarUrl: 'https://api.example.com/avatars/user1.jpg' },
        status: 200,
        message: 'Upload successful',
        timestamp: Date.now()
      };

      // Act
      service.uploadUserAvatar(userId, file).subscribe(response => {
        // Assert
        expect(response.data.avatarUrl).toBe('https://api.example.com/avatars/user1.jpg');
        done();
      });

      // Mock da requisição
      const req = httpMock.expectOne(`https://api.example.com/users/${userId}/avatar`);
      expect(req.request.method).toBe('POST');
      expect(req.request.body).toBeInstanceOf(FormData);
      
      // Verifica se o arquivo foi anexado
      const formData = req.request.body as FormData;
      expect(formData.get('file')).toBe(file);
      expect(formData.get('description')).toBe('Profile avatar');
      
      req.flush(mockResponse);
    });
  });

  describe('File Download', () => {
    it('deve fazer download de arquivo', (done) => {
      // Arrange
      const mockBlob = new Blob(['test content'], { type: 'application/pdf' });

      // Act
      service.downloadUsersReport('pdf').subscribe(blob => {
        // Assert
        expect(blob).toBeInstanceOf(Blob);
        expect(blob.type).toBe('application/pdf');
        done();
      });

      // Mock da requisição
      const req = httpMock.expectOne('https://api.example.com/users/report.pdf');
      expect(req.request.method).toBe('GET');
      expect(req.request.responseType).toBe('blob');
      req.flush(mockBlob);
    });
  });

  describe('Error Handling', () => {
    it('deve tratar erro 404', (done) => {
      // Arrange
      const userId = 999;
      const errorResponse = new HttpErrorResponse({
        error: { message: 'User not found' },
        status: 404,
        statusText: 'Not Found'
      });

      // Act
      service.getUserById(userId).subscribe({
        next: () => fail('Should have failed'),
        error: (error) => {
          // Assert
          expect(error.status).toBe(404);
          expect(service.error()).toBe('Not Found: Resource not found');
          done();
        }
      });

      // Mock da requisição com erro
      const req = httpMock.expectOne(`https://api.example.com/users/${userId}`);
      req.flush(errorResponse.error, errorResponse);
    });

    it('deve tratar erro 500', (done) => {
      // Arrange
      const errorResponse = new HttpErrorResponse({
        error: { message: 'Internal server error' },
        status: 500,
        statusText: 'Internal Server Error'
      });

      // Act
      service.getUsers().subscribe({
        next: () => fail('Should have failed'),
        error: (error) => {
          // Assert
          expect(error.status).toBe(500);
          expect(service.error()).toBe('Internal Server Error: Server error occurred');
          done();
        }
      });

      // Mock da requisição com erro
      const req = httpMock.expectOne('https://api.example.com/users?page=1&pageSize=10');
      req.flush(errorResponse.error, errorResponse);
    });

    it('deve tratar erro de rede', (done) => {
      // Arrange
      const networkError = new ErrorEvent('Network error', {
        message: 'Connection failed'
      });

      // Act
      service.getUsers().subscribe({
        next: () => fail('Should have failed'),
        error: (error) => {
          // Assert
          expect(service.error()).toBe('Client Error: Connection failed');
          done();
        }
      });

      // Mock da requisição com erro de rede
      const req = httpMock.expectOne('https://api.example.com/users?page=1&pageSize=10');
      req.error(networkError);
    });
  });

  describe('Loading States', () => {
    it('deve gerenciar estado de loading', (done) => {
      // Arrange
      const mockResponse: ApiResponse<User[]> = {
        data: [],
        status: 200,
        message: 'Success',
        timestamp: Date.now()
      };

      // Verifica estado inicial
      expect(service.isLoading()).toBe(false);

      // Act
      service.getUsers().subscribe(() => {
        // Verifica estado após conclusão
        expect(service.isLoading()).toBe(false);
        done();
      });

      // Verifica estado durante requisição
      expect(service.isLoading()).toBe(true);

      // Mock da requisição
      const req = httpMock.expectOne('https://api.example.com/users?page=1&pageSize=10');
      req.flush(mockResponse);
    });
  });

  describe('Signals', () => {
    it('deve atualizar lastRequest signal', (done) => {
      // Arrange
      const mockResponse: ApiResponse<User[]> = {
        data: [],
        status: 200,
        message: 'Success',
        timestamp: Date.now()
      };

      // Act
      service.getUsers().subscribe(() => {
        // Assert
        expect(service.lastRequest()).toBe('GET /users');
        done();
      });

      // Mock da requisição
      const req = httpMock.expectOne('https://api.example.com/users?page=1&pageSize=10');
      req.flush(mockResponse);
    });

    it('deve limpar erro ao fazer nova requisição', (done) => {
      // Arrange
      const mockResponse: ApiResponse<User[]> = {
        data: [],
        status: 200,
        message: 'Success',
        timestamp: Date.now()
      };

      // Simula erro anterior
      service['errorSignal'].set('Previous error');

      // Act
      service.getUsers().subscribe(() => {
        // Assert
        expect(service.error()).toBeNull();
        done();
      });

      // Mock da requisição
      const req = httpMock.expectOne('https://api.example.com/users?page=1&pageSize=10');
      req.flush(mockResponse);
    });
  });

  describe('Utility Methods', () => {
    it('deve limpar erro manualmente', () => {
      // Arrange
      service['errorSignal'].set('Test error');
      expect(service.error()).toBe('Test error');

      // Act
      service.clearError();

      // Assert
      expect(service.error()).toBeNull();
    });

    it('deve resetar estado', () => {
      // Arrange
      service['loadingSignal'].set(true);
      service['errorSignal'].set('Test error');
      service['lastRequestSignal'].set('Test request');

      // Act
      service.reset();

      // Assert
      expect(service.isLoading()).toBe(false);
      expect(service.error()).toBeNull();
      expect(service.lastRequest()).toBe('');
    });
  });

  describe('Multiple Requests', () => {
    it('deve fazer múltiplas requisições simultâneas', (done) => {
      // Arrange
      const mockResponse1: ApiResponse<User[]> = {
        data: [{ id: 1, name: 'User 1', email: 'user1@test.com', role: 'user', active: true, createdAt: new Date() }],
        status: 200,
        message: 'Success',
        timestamp: Date.now()
      };

      const mockResponse2: ApiResponse<User> = {
        data: { id: 1, name: 'User 1', email: 'user1@test.com', role: 'user', active: true, createdAt: new Date() },
        status: 200,
        message: 'Success',
        timestamp: Date.now()
      };

      let completedRequests = 0;

      // Act
      service.getUsers().subscribe(() => {
        completedRequests++;
        if (completedRequests === 2) done();
      });

      service.getUserById(1).subscribe(() => {
        completedRequests++;
        if (completedRequests === 2) done();
      });

      // Mock das requisições
      const req1 = httpMock.expectOne('https://api.example.com/users?page=1&pageSize=10');
      const req2 = httpMock.expectOne('https://api.example.com/users/1');
      
      req1.flush(mockResponse1);
      req2.flush(mockResponse2);
    });
  });
});
