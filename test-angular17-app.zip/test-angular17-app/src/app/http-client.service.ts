import { Injectable, signal } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError, of } from 'rxjs';
import { map, catchError, retry, tap, finalize } from 'rxjs/operators';

export interface ApiResponse<T> {
  data: T;
  status: number;
  message: string;
  timestamp: number;
}

export interface User {
  id: number;
  name: string;
  email: string;
  role: 'admin' | 'user' | 'guest';
  active: boolean;
  createdAt: Date;
}

export interface CreateUserRequest {
  name: string;
  email: string;
  role: User['role'];
}

export interface UpdateUserRequest {
  name?: string;
  email?: string;
  role?: User['role'];
  active?: boolean;
}

export interface UserListResponse {
  users: User[];
  total: number;
  page: number;
  pageSize: number;
}

@Injectable({
  providedIn: 'root'
})
export class HttpClientService {
  private baseUrl = 'https://api.example.com';
  private apiKey = 'your-api-key';
  
  // Signals para estado
  private loadingSignal = signal(false);
  private errorSignal = signal<string | null>(null);
  private lastRequestSignal = signal<string>('');
  
  // Public readonly signals
  readonly isLoading = this.loadingSignal.asReadonly();
  readonly error = this.errorSignal.asReadonly();
  readonly lastRequest = this.lastRequestSignal.asReadonly();
  
  constructor(private http: HttpClient) {}
  
  /**
   * GET request genérico
   */
  get<T>(endpoint: string, params?: any): Observable<ApiResponse<T>> {
    this.setLoading(true);
    this.setLastRequest(`GET ${endpoint}`);
    
    const httpParams = this.buildHttpParams(params);
    const headers = this.getHeaders();
    
    return this.http.get<ApiResponse<T>>(`${this.baseUrl}${endpoint}`, {
      params: httpParams,
      headers
    }).pipe(
      tap(response => {
        this.setLoading(false);
        this.clearError();
      }),
      catchError(error => this.handleError(error)),
      finalize(() => this.setLoading(false))
    );
  }
  
  /**
   * POST request
   */
  post<T>(endpoint: string, data: any): Observable<ApiResponse<T>> {
    this.setLoading(true);
    this.setLastRequest(`POST ${endpoint}`);
    
    const headers = this.getHeaders();
    
    return this.http.post<ApiResponse<T>>(`${this.baseUrl}${endpoint}`, data, {
      headers
    }).pipe(
      tap(response => {
        this.setLoading(false);
        this.clearError();
      }),
      catchError(error => this.handleError(error)),
      finalize(() => this.setLoading(false))
    );
  }
  
  /**
   * PUT request
   */
  put<T>(endpoint: string, data: any): Observable<ApiResponse<T>> {
    this.setLoading(true);
    this.setLastRequest(`PUT ${endpoint}`);
    
    const headers = this.getHeaders();
    
    return this.http.put<ApiResponse<T>>(`${this.baseUrl}${endpoint}`, data, {
      headers
    }).pipe(
      tap(response => {
        this.setLoading(false);
        this.clearError();
      }),
      catchError(error => this.handleError(error)),
      finalize(() => this.setLoading(false))
    );
  }
  
  /**
   * DELETE request
   */
  delete<T>(endpoint: string): Observable<ApiResponse<T>> {
    this.setLoading(true);
    this.setLastRequest(`DELETE ${endpoint}`);
    
    const headers = this.getHeaders();
    
    return this.http.delete<ApiResponse<T>>(`${this.baseUrl}${endpoint}`, {
      headers
    }).pipe(
      tap(response => {
        this.setLoading(false);
        this.clearError();
      }),
      catchError(error => this.handleError(error)),
      finalize(() => this.setLoading(false))
    );
  }
  
  /**
   * PATCH request
   */
  patch<T>(endpoint: string, data: any): Observable<ApiResponse<T>> {
    this.setLoading(true);
    this.setLastRequest(`PATCH ${endpoint}`);
    
    const headers = this.getHeaders();
    
    return this.http.patch<ApiResponse<T>>(`${this.baseUrl}${endpoint}`, data, {
      headers
    }).pipe(
      tap(response => {
        this.setLoading(false);
        this.clearError();
      }),
      catchError(error => this.handleError(error)),
      finalize(() => this.setLoading(false))
    );
  }
  
  /**
   * Upload file
   */
  uploadFile<T>(endpoint: string, file: File, additionalData?: any): Observable<ApiResponse<T>> {
    this.setLoading(true);
    this.setLastRequest(`UPLOAD ${endpoint}`);
    
    const formData = new FormData();
    formData.append('file', file);
    
    if (additionalData) {
      Object.keys(additionalData).forEach(key => {
        formData.append(key, additionalData[key]);
      });
    }
    
    const headers = this.getHeaders(false); // No Content-Type for FormData
    
    return this.http.post<ApiResponse<T>>(`${this.baseUrl}${endpoint}`, formData, {
      headers
    }).pipe(
      tap(response => {
        this.setLoading(false);
        this.clearError();
      }),
      catchError(error => this.handleError(error)),
      finalize(() => this.setLoading(false))
    );
  }
  
  /**
   * Download file
   */
  downloadFile(endpoint: string, filename?: string): Observable<Blob> {
    this.setLoading(true);
    this.setLastRequest(`DOWNLOAD ${endpoint}`);
    
    const headers = this.getHeaders();
    
    return this.http.get(`${this.baseUrl}${endpoint}`, {
      headers,
      responseType: 'blob'
    }).pipe(
      tap(() => {
        this.setLoading(false);
        this.clearError();
      }),
      catchError(error => this.handleError(error)),
      finalize(() => this.setLoading(false))
    );
  }
  
  /**
   * Obtém todos os usuários
   */
  getUsers(page: number = 1, pageSize: number = 10): Observable<ApiResponse<UserListResponse>> {
    const params = { page: page.toString(), pageSize: pageSize.toString() };
    return this.get<UserListResponse>('/users', params);
  }
  
  /**
   * Obtém usuário por ID
   */
  getUserById(id: number): Observable<ApiResponse<User>> {
    return this.get<User>(`/users/${id}`);
  }
  
  /**
   * Cria novo usuário
   */
  createUser(userData: CreateUserRequest): Observable<ApiResponse<User>> {
    return this.post<User>('/users', userData);
  }
  
  /**
   * Atualiza usuário
   */
  updateUser(id: number, userData: UpdateUserRequest): Observable<ApiResponse<User>> {
    return this.put<User>(`/users/${id}`, userData);
  }
  
  /**
   * Atualiza parcialmente usuário
   */
  patchUser(id: number, userData: Partial<UpdateUserRequest>): Observable<ApiResponse<User>> {
    return this.patch<User>(`/users/${id}`, userData);
  }
  
  /**
   * Deleta usuário
   */
  deleteUser(id: number): Observable<ApiResponse<void>> {
    return this.delete<void>(`/users/${id}`);
  }
  
  /**
   * Busca usuários por role
   */
  getUsersByRole(role: User['role']): Observable<ApiResponse<User[]>> {
    const params = { role };
    return this.get<User[]>('/users/search', params);
  }
  
  /**
   * Busca usuários ativos
   */
  getActiveUsers(): Observable<ApiResponse<User[]>> {
    const params = { active: 'true' };
    return this.get<User[]>('/users/search', params);
  }
  
  /**
   * Busca usuários com filtros
   */
  searchUsers(filters: {
    name?: string;
    email?: string;
    role?: User['role'];
    active?: boolean;
    page?: number;
    pageSize?: number;
  }): Observable<ApiResponse<UserListResponse>> {
    const params = this.buildHttpParams(filters);
    return this.get<UserListResponse>('/users/search', params);
  }
  
  /**
   * Upload avatar do usuário
   */
  uploadUserAvatar(userId: number, file: File): Observable<ApiResponse<{ avatarUrl: string }>> {
    return this.uploadFile<{ avatarUrl: string }>(`/users/${userId}/avatar`, file);
  }
  
  /**
   * Download relatório de usuários
   */
  downloadUsersReport(format: 'pdf' | 'excel' = 'pdf'): Observable<Blob> {
    return this.downloadFile(`/users/report.${format}`);
  }
  
  /**
   * Limpa erro
   */
  clearError(): void {
    this.errorSignal.set(null);
  }
  
  /**
   * Reseta estado
   */
  reset(): void {
    this.setLoading(false);
    this.clearError();
    this.setLastRequest('');
  }
  
  // Private methods
  
  private setLoading(loading: boolean): void {
    this.loadingSignal.set(loading);
  }
  
  private setLastRequest(request: string): void {
    this.lastRequestSignal.set(request);
  }
  
  private clearError(): void {
    this.errorSignal.set(null);
  }
  
  private getHeaders(includeContentType: boolean = true): HttpHeaders {
    let headers = new HttpHeaders({
      'Authorization': `Bearer ${this.apiKey}`,
      'X-Requested-With': 'XMLHttpRequest'
    });
    
    if (includeContentType) {
      headers = headers.set('Content-Type', 'application/json');
    }
    
    return headers;
  }
  
  private buildHttpParams(params: any): HttpParams {
    let httpParams = new HttpParams();
    
    if (params) {
      Object.keys(params).forEach(key => {
        if (params[key] !== null && params[key] !== undefined) {
          httpParams = httpParams.set(key, params[key].toString());
        }
      });
    }
    
    return httpParams;
  }
  
  private handleError(error: HttpErrorResponse): Observable<never> {
    let errorMessage = 'An unknown error occurred';
    
    if (error.error instanceof ErrorEvent) {
      // Client-side error
      errorMessage = `Client Error: ${error.error.message}`;
    } else {
      // Server-side error
      errorMessage = `Server Error: ${error.status} - ${error.message}`;
      
      switch (error.status) {
        case 400:
          errorMessage = 'Bad Request: Invalid data provided';
          break;
        case 401:
          errorMessage = 'Unauthorized: Authentication required';
          break;
        case 403:
          errorMessage = 'Forbidden: Access denied';
          break;
        case 404:
          errorMessage = 'Not Found: Resource not found';
          break;
        case 500:
          errorMessage = 'Internal Server Error: Server error occurred';
          break;
        default:
          errorMessage = `HTTP Error ${error.status}: ${error.message}`;
      }
    }
    
    this.errorSignal.set(errorMessage);
    return throwError(() => error);
  }
}
