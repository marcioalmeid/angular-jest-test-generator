import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { HttpErrorResponse } from '@angular/common/http';
import { SimpleHttpService, User } from './simple-http.service';

describe('SimpleHttpService', () => {
  let service: SimpleHttpService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [SimpleHttpService]
    });

    service = TestBed.inject(SimpleHttpService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  describe('Criação do Serviço', () => {
    it('deve ser criado com sucesso', () => {
      expect(service).toBeTruthy();
    });

    it('deve ser uma instância de SimpleHttpService', () => {
      expect(service).toBeInstanceOf(SimpleHttpService);
    });
  });

  describe('getUsers', () => {
    it('deve retornar lista de usuários', (done) => {
      const mockUsers: User[] = [
        { id: 1, name: 'João', email: 'joao@test.com' },
        { id: 2, name: 'Maria', email: 'maria@test.com' }
      ];

      service.getUsers().subscribe(users => {
        expect(users).toEqual(mockUsers);
        expect(users).toHaveLength(2);
        done();
      });

      const req = httpMock.expectOne('https://api.example.com/users');
      expect(req.request.method).toBe('GET');
      req.flush(mockUsers);
    });

    it('deve gerenciar estado de loading', (done) => {
      const mockUsers: User[] = [];

      expect(service.isLoading()).toBe(false);

      service.getUsers().subscribe(() => {
        expect(service.isLoading()).toBe(false);
        done();
      });

      expect(service.isLoading()).toBe(true);

      const req = httpMock.expectOne('https://api.example.com/users');
      req.flush(mockUsers);
    });

    it('deve tratar erro 500', (done) => {
      service.getUsers().subscribe({
        next: () => fail('Deveria ter falhado'),
        error: (error) => {
          expect(error.status).toBe(500);
          expect(service.error()).toBe('Erro na requisição');
          done();
        }
      });

      const req = httpMock.expectOne('https://api.example.com/users');
      req.flush('Server Error', { 
        status: 500, 
        statusText: 'Internal Server Error' 
      });
    });
  });

  describe('getUserById', () => {
    it('deve retornar usuário por ID', (done) => {
      const mockUser: User = { id: 1, name: 'João', email: 'joao@test.com' };

      service.getUserById(1).subscribe(user => {
        expect(user).toEqual(mockUser);
        expect(user.id).toBe(1);
        done();
      });

      const req = httpMock.expectOne('https://api.example.com/users/1');
      expect(req.request.method).toBe('GET');
      req.flush(mockUser);
    });

    it('deve tratar erro 404', (done) => {
      service.getUserById(999).subscribe({
        next: () => fail('Deveria ter falhado'),
        error: (error) => {
          expect(error.status).toBe(404);
          done();
        }
      });

      const req = httpMock.expectOne('https://api.example.com/users/999');
      req.flush('Not Found', { 
        status: 404, 
        statusText: 'Not Found' 
      });
    });
  });

  describe('createUser', () => {
    it('deve criar usuário', (done) => {
      const newUser = { name: 'Pedro', email: 'pedro@test.com' };
      const createdUser: User = { id: 3, ...newUser };

      service.createUser(newUser).subscribe(user => {
        expect(user).toEqual(createdUser);
        expect(user.id).toBe(3);
        done();
      });

      const req = httpMock.expectOne('https://api.example.com/users');
      expect(req.request.method).toBe('POST');
      expect(req.request.body).toEqual(newUser);
      req.flush(createdUser);
    });
  });

  describe('updateUser', () => {
    it('deve atualizar usuário', (done) => {
      const userId = 1;
      const updateData = { name: 'João Atualizado' };
      const updatedUser: User = { id: 1, name: 'João Atualizado', email: 'joao@test.com' };

      service.updateUser(userId, updateData).subscribe(user => {
        expect(user).toEqual(updatedUser);
        done();
      });

      const req = httpMock.expectOne('https://api.example.com/users/1');
      expect(req.request.method).toBe('PUT');
      expect(req.request.body).toEqual(updateData);
      req.flush(updatedUser);
    });
  });

  describe('deleteUser', () => {
    it('deve deletar usuário', (done) => {
      const userId = 1;

      service.deleteUser(userId).subscribe(() => {
        expect(true).toBe(true);
        done();
      });

      const req = httpMock.expectOne('https://api.example.com/users/1');
      expect(req.request.method).toBe('DELETE');
      req.flush(null);
    });
  });

  describe('searchUsers', () => {
    it('deve buscar usuários com query', (done) => {
      const query = 'joao';
      const mockUsers: User[] = [
        { id: 1, name: 'João', email: 'joao@test.com' }
      ];

      service.searchUsers(query).subscribe(users => {
        expect(users).toEqual(mockUsers);
        done();
      });

      const req = httpMock.expectOne('https://api.example.com/users/search?q=joao');
      expect(req.request.method).toBe('GET');
      expect(req.request.params.get('q')).toBe('joao');
      req.flush(mockUsers);
    });
  });

  describe('Utility Methods', () => {
    it('deve limpar erro', () => {
      service['errorSignal'].set('Test error');
      expect(service.error()).toBe('Test error');

      service.clearError();
      expect(service.error()).toBeNull();
    });

    it('deve resetar estado', () => {
      service['loadingSignal'].set(true);
      service['errorSignal'].set('Test error');

      service.reset();

      expect(service.isLoading()).toBe(false);
      expect(service.error()).toBeNull();
    });
  });

  describe('Error Handling', () => {
    it('deve tratar erro de rede', (done) => {
      service.getUsers().subscribe({
        next: () => fail('Deveria ter falhado'),
        error: (error) => {
          expect(service.error()).toBe('Erro na requisição');
          done();
        }
      });

      const req = httpMock.expectOne('https://api.example.com/users');
      req.error(new ErrorEvent('Network error'));
    });
  });
});
