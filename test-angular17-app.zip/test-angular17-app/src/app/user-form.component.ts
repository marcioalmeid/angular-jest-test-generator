import { Component, signal, computed, input, output, effect, ViewChild, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface ValidationError {
  field: string;
  message: string;
}

interface UserFormData {
  name: string;
  email: string;
  age: number;
  country: string;
  acceptTerms: boolean;
}

@Component({
  selector: 'app-user-form',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <form class="user-form" (ngSubmit)="handleSubmit()">
      <h2>User Registration</h2>
      
      <div class="form-group">
        <label for="name">Name:</label>
        <input 
          #nameInput
          id="name" 
          name="name"
          type="text" 
          [(ngModel)]="formData.name"
          (blur)="validateField('name')"
          [class.error]="hasError('name')"
        />
        @if (hasError('name')) {
          <span class="error-message">{{ getError('name') }}</span>
        }
      </div>

      <div class="form-group">
        <label for="email">Email:</label>
        <input 
          id="email" 
          name="email"
          type="email" 
          [(ngModel)]="formData.email"
          (blur)="validateField('email')"
          [class.error]="hasError('email')"
        />
        @if (hasError('email')) {
          <span class="error-message">{{ getError('email') }}</span>
        }
      </div>

      <div class="form-group">
        <label for="age">Age:</label>
        <input 
          id="age" 
          name="age"
          type="number" 
          [(ngModel)]="formData.age"
          (blur)="validateField('age')"
          [class.error]="hasError('age')"
        />
        @if (hasError('age')) {
          <span class="error-message">{{ getError('age') }}</span>
        }
      </div>

      <div class="form-group">
        <label for="country">Country:</label>
        <select 
          id="country" 
          name="country"
          [(ngModel)]="formData.country"
          (change)="validateField('country')"
        >
          <option value="">Select...</option>
          @for (country of countries(); track country) {
            <option [value]="country">{{ country }}</option>
          }
        </select>
      </div>

      <div class="form-group checkbox">
        <label>
          <input 
            type="checkbox" 
            name="acceptTerms"
            [(ngModel)]="formData.acceptTerms"
            (change)="validateField('acceptTerms')"
          />
          I accept the terms and conditions
        </label>
        @if (hasError('acceptTerms')) {
          <span class="error-message">{{ getError('acceptTerms') }}</span>
        }
      </div>

      <div class="form-summary">
        <p>Form Status: {{ formStatus() }}</p>
        <p>Valid Fields: {{ validFieldsCount() }} / {{ totalFields() }}</p>
        @if (isFormValid()) {
          <p class="success">✓ Form is ready to submit!</p>
        }
      </div>

      <div class="form-actions">
        <button 
          type="submit" 
          [disabled]="!isFormValid() || isSubmitting()"
          class="btn-primary"
        >
          @if (isSubmitting()) {
            <span>Submitting...</span>
          } @else {
            <span>Submit</span>
          }
        </button>
        <button 
          type="button" 
          (click)="resetForm()"
          class="btn-secondary"
        >
          Reset
        </button>
      </div>

      @if (submitSuccess()) {
        <div class="alert success">
          Form submitted successfully!
        </div>
      }

      @if (submitError()) {
        <div class="alert error">
          {{ submitError() }}
        </div>
      }
    </form>
  `,
  styles: [`
    .user-form {
      max-width: 500px;
      margin: 20px auto;
      padding: 30px;
      border: 1px solid #ddd;
      border-radius: 8px;
    }
    
    .form-group {
      margin-bottom: 20px;
    }
    
    label {
      display: block;
      margin-bottom: 5px;
      font-weight: bold;
    }
    
    input, select {
      width: 100%;
      padding: 8px;
      border: 1px solid #ccc;
      border-radius: 4px;
    }
    
    input.error {
      border-color: #dc3545;
    }
    
    .error-message {
      color: #dc3545;
      font-size: 12px;
      margin-top: 5px;
      display: block;
    }
    
    .form-summary {
      background: #f8f9fa;
      padding: 15px;
      border-radius: 4px;
      margin: 20px 0;
    }
    
    .success {
      color: #28a745;
    }
    
    .alert {
      padding: 10px;
      border-radius: 4px;
      margin-top: 15px;
    }
    
    .alert.success {
      background: #d4edda;
      border: 1px solid #c3e6cb;
    }
    
    .alert.error {
      background: #f8d7da;
      border: 1px solid #f5c6cb;
      color: #721c24;
    }
  `]
})
export class UserFormComponent {
  @ViewChild('nameInput') nameInput!: ElementRef<HTMLInputElement>;
  
  // Inputs
  initialData = input<Partial<UserFormData>>();
  readonly = input<boolean>(false);
  
  // Outputs
  formSubmitted = output<UserFormData>();
  formChanged = output<Partial<UserFormData>>();
  validationChanged = output<boolean>();
  
  // Form data
  formData: UserFormData = {
    name: '',
    email: '',
    age: 0,
    country: '',
    acceptTerms: false
  };
  
  // Signals
  errors = signal<ValidationError[]>([]);
  isSubmitting = signal(false);
  submitSuccess = signal(false);
  submitError = signal<string>('');
  countries = signal(['USA', 'Canada', 'UK', 'Germany', 'France', 'Brazil']);
  
  // Computed signals
  isFormValid = computed(() => {
    return this.errors().length === 0 && 
           this.formData.name.length > 0 &&
           this.formData.email.length > 0 &&
           this.formData.acceptTerms;
  });
  
  formStatus = computed(() => {
    if (this.isFormValid()) return 'Valid';
    if (this.errors().length > 0) return 'Invalid';
    return 'Incomplete';
  });
  
  validFieldsCount = computed(() => {
    return 5 - this.errors().length;
  });
  
  totalFields = computed(() => 5);
  
  constructor() {
    // Effect para monitorar mudanças
    effect(() => {
      const isValid = this.isFormValid();
      this.validationChanged.emit(isValid);
    });
    
    // Inicializar com dados se fornecidos
    const initial = this.initialData();
    if (initial) {
      this.formData = { ...this.formData, ...initial };
    }
  }
  
  ngAfterViewInit(): void {
    // Focar no primeiro campo
    setTimeout(() => {
      this.nameInput?.nativeElement.focus();
    }, 0);
  }
  
  validateField(field: keyof UserFormData): void {
    // Remove erro existente do campo
    this.errors.update(errors => 
      errors.filter(e => e.field !== field)
    );
    
    // Validações específicas
    switch (field) {
      case 'name':
        if (!this.formData.name || this.formData.name.length < 3) {
          this.addError(field, 'Name must be at least 3 characters');
        }
        break;
        
      case 'email':
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!this.formData.email || !emailRegex.test(this.formData.email)) {
          this.addError(field, 'Invalid email format');
        }
        break;
        
      case 'age':
        if (this.formData.age < 18 || this.formData.age > 120) {
          this.addError(field, 'Age must be between 18 and 120');
        }
        break;
        
      case 'country':
        if (!this.formData.country) {
          this.addError(field, 'Please select a country');
        }
        break;
        
      case 'acceptTerms':
        if (!this.formData.acceptTerms) {
          this.addError(field, 'You must accept the terms');
        }
        break;
    }
    
    this.formChanged.emit(this.formData);
  }
  
  validateAll(): boolean {
    const fields: (keyof UserFormData)[] = ['name', 'email', 'age', 'country', 'acceptTerms'];
    fields.forEach(field => this.validateField(field));
    return this.isFormValid();
  }
  
  addError(field: string, message: string): void {
    this.errors.update(errors => [...errors, { field, message }]);
  }
  
  hasError(field: string): boolean {
    return this.errors().some(e => e.field === field);
  }
  
  getError(field: string): string {
    const error = this.errors().find(e => e.field === field);
    return error ? error.message : '';
  }
  
  async handleSubmit(): Promise<void> {
    if (!this.validateAll()) {
      return;
    }
    
    this.isSubmitting.set(true);
    this.submitError.set('');
    this.submitSuccess.set(false);
    
    try {
      // Simula chamada API
      await this.simulateApiCall();
      
      this.submitSuccess.set(true);
      this.formSubmitted.emit(this.formData);
      
      // Reset após sucesso
      setTimeout(() => {
        this.resetForm();
        this.submitSuccess.set(false);
      }, 2000);
      
    } catch (error) {
      this.submitError.set('Failed to submit form. Please try again.');
    } finally {
      this.isSubmitting.set(false);
    }
  }
  
  resetForm(): void {
    this.formData = {
      name: '',
      email: '',
      age: 0,
      country: '',
      acceptTerms: false
    };
    this.errors.set([]);
    this.submitError.set('');
    this.submitSuccess.set(false);
    this.nameInput?.nativeElement.focus();
  }
  
  setFormData(data: Partial<UserFormData>): void {
    this.formData = { ...this.formData, ...data };
    this.validateAll();
  }
  
  getFormData(): UserFormData {
    return { ...this.formData };
  }
  
  private simulateApiCall(): Promise<void> {
    return new Promise((resolve) => {
      setTimeout(resolve, 1000);
    });
  }
}

