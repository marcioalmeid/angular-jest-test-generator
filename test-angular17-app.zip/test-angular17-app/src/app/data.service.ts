import { Injectable, signal } from '@angular/core';
import { Observable, of, delay, throwError } from 'rxjs';

export interface TodoItem {
  id: number;
  title: string;
  completed: boolean;
  createdAt: Date;
}

@Injectable({
  providedIn: 'root'
})
export class DataService {
  // Signal para armazenar dados
  private todosSignal = signal<TodoItem[]>([]);
  
  // Getter público para o signal
  readonly todos = this.todosSignal.asReadonly();
  
  private nextId = 1;
  
  constructor() {
    // Dados iniciais
    this.addTodo('Learn Angular 17');
    this.addTodo('Master Signals');
  }
  
  /**
   * Obtém todos os itens
   */
  getTodos(): Observable<TodoItem[]> {
    return of(this.todosSignal()).pipe(delay(100));
  }
  
  /**
   * Obtém um item por ID
   */
  getTodoById(id: number): Observable<TodoItem | undefined> {
    const todo = this.todosSignal().find(t => t.id === id);
    if (!todo) {
      return throwError(() => new Error(`Todo with id ${id} not found`));
    }
    return of(todo).pipe(delay(50));
  }
  
  /**
   * Adiciona novo item
   */
  addTodo(title: string): TodoItem {
    const newTodo: TodoItem = {
      id: this.nextId++,
      title,
      completed: false,
      createdAt: new Date()
    };
    
    this.todosSignal.update(todos => [...todos, newTodo]);
    return newTodo;
  }
  
  /**
   * Atualiza um item existente
   */
  updateTodo(id: number, updates: Partial<TodoItem>): boolean {
    const index = this.todosSignal().findIndex(t => t.id === id);
    
    if (index === -1) {
      return false;
    }
    
    this.todosSignal.update(todos => {
      const updated = [...todos];
      updated[index] = { ...updated[index], ...updates };
      return updated;
    });
    
    return true;
  }
  
  /**
   * Marca item como completo
   */
  toggleComplete(id: number): boolean {
    const todo = this.todosSignal().find(t => t.id === id);
    if (!todo) {
      return false;
    }
    return this.updateTodo(id, { completed: !todo.completed });
  }
  
  /**
   * Remove um item
   */
  deleteTodo(id: number): boolean {
    const initialLength = this.todosSignal().length;
    this.todosSignal.update(todos => todos.filter(t => t.id !== id));
    return this.todosSignal().length < initialLength;
  }
  
  /**
   * Obtém itens completos
   */
  getCompletedTodos(): TodoItem[] {
    return this.todosSignal().filter(t => t.completed);
  }
  
  /**
   * Obtém itens pendentes
   */
  getPendingTodos(): TodoItem[] {
    return this.todosSignal().filter(t => !t.completed);
  }
  
  /**
   * Obtém estatísticas
   */
  getStats(): { total: number; completed: number; pending: number } {
    const todos = this.todosSignal();
    return {
      total: todos.length,
      completed: todos.filter(t => t.completed).length,
      pending: todos.filter(t => !t.completed).length
    };
  }
  
  /**
   * Limpa todos os itens
   */
  clear(): void {
    this.todosSignal.set([]);
  }
  
  /**
   * Limpa apenas itens completos
   */
  clearCompleted(): number {
    const initialLength = this.todosSignal().length;
    this.todosSignal.update(todos => todos.filter(t => !t.completed));
    return initialLength - this.todosSignal().length;
  }
}

