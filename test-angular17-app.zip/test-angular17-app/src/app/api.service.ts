import { Injectable, signal } from '@angular/core';
import { Observable, of, throwError, BehaviorSubject, Subject } from 'rxjs';
import { delay, map, catchError, retry, tap, finalize } from 'rxjs/operators';

export interface ApiResponse<T> {
  data: T;
  status: number;
  message: string;
  timestamp: number;
}

export interface User {
  id: number;
  name: string;
  email: string;
  role: 'admin' | 'user' | 'guest';
  active: boolean;
  createdAt: Date;
}

export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
  hasMore: boolean;
}

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  // Signals para estado
  private loadingSignal = signal(false);
  private errorSignal = signal<string | null>(null);
  private usersSignal = signal<User[]>([]);
  
  // Public readonly signals
  readonly isLoading = this.loadingSignal.asReadonly();
  readonly error = this.errorSignal.asReadonly();
  readonly users = this.usersSignal.asReadonly();
  
  // Subjects para eventos
  private requestStart$ = new Subject<string>();
  private requestEnd$ = new Subject<string>();
  
  // BehaviorSubject para cache
  private cache$ = new BehaviorSubject<Map<string, any>>(new Map());
  
  // Estatísticas
  private stats = signal({
    totalRequests: 0,
    successfulRequests: 0,
    failedRequests: 0,
    averageResponseTime: 0
  });
  
  readonly statistics = this.stats.asReadonly();
  
  constructor() {
    // Mock data inicial
    this.initMockData();
  }
  
  /**
   * GET request genérico
   */
  get<T>(endpoint: string, useCache: boolean = false): Observable<ApiResponse<T>> {
    this.startRequest(endpoint);
    
    if (useCache) {
      const cached = this.getFromCache(endpoint);
      if (cached) {
        this.endRequest(endpoint, true);
        return of(cached).pipe(delay(50));
      }
    }
    
    return this.simulateHttpGet<T>(endpoint).pipe(
      tap(response => this.saveToCache(endpoint, response)),
      tap(() => this.endRequest(endpoint, true)),
      catchError(error => {
        this.endRequest(endpoint, false);
        return throwError(() => error);
      })
    );
  }
  
  /**
   * POST request
   */
  post<T>(endpoint: string, data: any): Observable<ApiResponse<T>> {
    this.startRequest(endpoint);
    
    return this.simulateHttpPost<T>(endpoint, data).pipe(
      tap(() => this.endRequest(endpoint, true)),
      catchError(error => {
        this.endRequest(endpoint, false);
        return throwError(() => error);
      })
    );
  }
  
  /**
   * PUT request
   */
  put<T>(endpoint: string, data: any): Observable<ApiResponse<T>> {
    this.startRequest(endpoint);
    
    return this.simulateHttpPut<T>(endpoint, data).pipe(
      tap(() => this.endRequest(endpoint, true)),
      catchError(error => {
        this.endRequest(endpoint, false);
        return throwError(() => error);
      })
    );
  }
  
  /**
   * DELETE request
   */
  delete<T>(endpoint: string): Observable<ApiResponse<T>> {
    this.startRequest(endpoint);
    
    return this.simulateHttpDelete<T>(endpoint).pipe(
      tap(() => this.endRequest(endpoint, true)),
      catchError(error => {
        this.endRequest(endpoint, false);
        return throwError(() => error);
      })
    );
  }
  
  /**
   * Obtém todos os usuários
   */
  getUsers(): Observable<ApiResponse<User[]>> {
    return this.get<User[]>('/users', true).pipe(
      tap(response => this.usersSignal.set(response.data))
    );
  }
  
  /**
   * Obtém usuário por ID
   */
  getUserById(id: number): Observable<ApiResponse<User>> {
    return this.get<User>(`/users/${id}`).pipe(
      retry(2),
      catchError(error => {
        this.errorSignal.set(`Failed to get user ${id}`);
        return throwError(() => error);
      })
    );
  }
  
  /**
   * Cria novo usuário
   */
  createUser(user: Omit<User, 'id' | 'createdAt'>): Observable<ApiResponse<User>> {
    return this.post<User>('/users', user).pipe(
      tap(response => {
        this.usersSignal.update(users => [...users, response.data]);
      })
    );
  }
  
  /**
   * Atualiza usuário
   */
  updateUser(id: number, updates: Partial<User>): Observable<ApiResponse<User>> {
    return this.put<User>(`/users/${id}`, updates).pipe(
      tap(response => {
        this.usersSignal.update(users => 
          users.map(u => u.id === id ? response.data : u)
        );
      })
    );
  }
  
  /**
   * Deleta usuário
   */
  deleteUser(id: number): Observable<ApiResponse<void>> {
    return this.delete<void>(`/users/${id}`).pipe(
      tap(() => {
        this.usersSignal.update(users => users.filter(u => u.id !== id));
      })
    );
  }
  
  /**
   * Busca paginada
   */
  getUsersPaginated(page: number, pageSize: number): Observable<ApiResponse<PaginatedResponse<User>>> {
    const allUsers = this.usersSignal();
    const start = (page - 1) * pageSize;
    const end = start + pageSize;
    const items = allUsers.slice(start, end);
    
    const paginatedData: PaginatedResponse<User> = {
      items,
      total: allUsers.length,
      page,
      pageSize,
      hasMore: end < allUsers.length
    };
    
    return of({
      data: paginatedData,
      status: 200,
      message: 'Success',
      timestamp: Date.now()
    }).pipe(delay(300));
  }
  
  /**
   * Busca usuários por role
   */
  getUsersByRole(role: User['role']): Observable<ApiResponse<User[]>> {
    const filtered = this.usersSignal().filter(u => u.role === role);
    
    return of({
      data: filtered,
      status: 200,
      message: 'Success',
      timestamp: Date.now()
    }).pipe(delay(200));
  }
  
  /**
   * Busca usuários ativos
   */
  getActiveUsers(): Observable<ApiResponse<User[]>> {
    const active = this.usersSignal().filter(u => u.active);
    
    return of({
      data: active,
      status: 200,
      message: 'Success',
      timestamp: Date.now()
    }).pipe(delay(200));
  }
  
  /**
   * Limpa cache
   */
  clearCache(): void {
    this.cache$.next(new Map());
  }
  
  /**
   * Limpa erro
   */
  clearError(): void {
    this.errorSignal.set(null);
  }
  
  /**
   * Reseta estatísticas
   */
  resetStats(): void {
    this.stats.set({
      totalRequests: 0,
      successfulRequests: 0,
      failedRequests: 0,
      averageResponseTime: 0
    });
  }
  
  /**
   * Obtém observável de eventos de request
   */
  getRequestEvents(): Observable<{ type: 'start' | 'end'; endpoint: string }> {
    return new Observable(observer => {
      const startSub = this.requestStart$.subscribe(endpoint => 
        observer.next({ type: 'start', endpoint })
      );
      const endSub = this.requestEnd$.subscribe(endpoint => 
        observer.next({ type: 'end', endpoint })
      );
      
      return () => {
        startSub.unsubscribe();
        endSub.unsubscribe();
      };
    });
  }
  
  // Private methods
  
  private startRequest(endpoint: string): void {
    this.loadingSignal.set(true);
    this.requestStart$.next(endpoint);
    this.stats.update(s => ({ ...s, totalRequests: s.totalRequests + 1 }));
  }
  
  private endRequest(endpoint: string, success: boolean): void {
    this.loadingSignal.set(false);
    this.requestEnd$.next(endpoint);
    
    if (success) {
      this.stats.update(s => ({ 
        ...s, 
        successfulRequests: s.successfulRequests + 1 
      }));
    } else {
      this.stats.update(s => ({ 
        ...s, 
        failedRequests: s.failedRequests + 1 
      }));
    }
  }
  
  private getFromCache(key: string): any {
    return this.cache$.value.get(key);
  }
  
  private saveToCache(key: string, value: any): void {
    const cache = new Map(this.cache$.value);
    cache.set(key, value);
    this.cache$.next(cache);
  }
  
  private simulateHttpGet<T>(endpoint: string): Observable<ApiResponse<T>> {
    // Simula resposta HTTP
    return of({
      data: {} as T,
      status: 200,
      message: 'Success',
      timestamp: Date.now()
    }).pipe(delay(500));
  }
  
  private simulateHttpPost<T>(endpoint: string, data: any): Observable<ApiResponse<T>> {
    return of({
      data: { ...data, id: Math.random() } as T,
      status: 201,
      message: 'Created',
      timestamp: Date.now()
    }).pipe(delay(600));
  }
  
  private simulateHttpPut<T>(endpoint: string, data: any): Observable<ApiResponse<T>> {
    return of({
      data: data as T,
      status: 200,
      message: 'Updated',
      timestamp: Date.now()
    }).pipe(delay(500));
  }
  
  private simulateHttpDelete<T>(endpoint: string): Observable<ApiResponse<T>> {
    return of({
      data: {} as T,
      status: 204,
      message: 'Deleted',
      timestamp: Date.now()
    }).pipe(delay(400));
  }
  
  private initMockData(): void {
    const mockUsers: User[] = [
      {
        id: 1,
        name: 'Admin User',
        email: 'admin@test.com',
        role: 'admin',
        active: true,
        createdAt: new Date('2024-01-01')
      },
      {
        id: 2,
        name: 'Regular User',
        email: 'user@test.com',
        role: 'user',
        active: true,
        createdAt: new Date('2024-01-15')
      },
      {
        id: 3,
        name: 'Guest User',
        email: 'guest@test.com',
        role: 'guest',
        active: false,
        createdAt: new Date('2024-02-01')
      }
    ];
    
    this.usersSignal.set(mockUsers);
  }
}

