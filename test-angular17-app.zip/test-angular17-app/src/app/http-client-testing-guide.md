# 🧪 Guia Completo: Testando HttpClient com Mocks

## 📋 Índice
1. [Configuração Básica](#configuração-básica)
2. [Mocks vs HttpTestingController](#mocks-vs-httptestingcontroller)
3. [Exemplos Práticos](#exemplos-práticos)
4. [Tratamento de Erros](#tratamento-de-erros)
5. [Testes Avançados](#testes-avançados)
6. [Boas Práticas](#boas-práticas)

## 🔧 Configuração Básica

### 1. Setup do TestBed

```typescript
import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

describe('MeuServico', () => {
  let service: MeuServico;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [MeuServico]
    });

    service = TestBed.inject(MeuServico);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify(); // Verifica se não há requests pendentes
  });
});
```

### 2. Configuração com Mocks Manuais

```typescript
import { HttpClient } from '@angular/common/http';
import { of } from 'rxjs';

describe('MeuServico com Mock Manual', () => {
  let service: MeuServico;
  let mockHttpClient: jest.Mocked<HttpClient>;

  beforeEach(() => {
    const mockHttpClientSpy = {
      get: jest.fn(),
      post: jest.fn(),
      put: jest.fn(),
      delete: jest.fn(),
      patch: jest.fn()
    };

    TestBed.configureTestingModule({
      providers: [
        MeuServico,
        { provide: HttpClient, useValue: mockHttpClientSpy }
      ]
    });

    service = TestBed.inject(MeuServico);
    mockHttpClient = TestBed.inject(HttpClient) as jest.Mocked<HttpClient>;
  });
});
```

## 🆚 Mocks vs HttpTestingController

### HttpTestingController (Recomendado)
```typescript
it('deve fazer GET request', (done) => {
  const mockResponse = { data: 'test' };

  service.getData().subscribe(response => {
    expect(response).toEqual(mockResponse);
    done();
  });

  const req = httpMock.expectOne('https://api.example.com/data');
  expect(req.request.method).toBe('GET');
  req.flush(mockResponse);
});
```

### Mock Manual
```typescript
it('deve fazer GET request com mock', () => {
  const mockResponse = { data: 'test' };
  mockHttpClient.get.mockReturnValue(of(mockResponse));

  service.getData().subscribe(response => {
    expect(response).toEqual(mockResponse);
  });

  expect(mockHttpClient.get).toHaveBeenCalledWith(
    'https://api.example.com/data',
    expect.any(Object)
  );
});
```

## 📝 Exemplos Práticos

### 1. GET Request
```typescript
it('deve buscar usuários', (done) => {
  const mockUsers = [
    { id: 1, name: 'João' },
    { id: 2, name: 'Maria' }
  ];

  service.getUsers().subscribe(users => {
    expect(users).toEqual(mockUsers);
    done();
  });

  const req = httpMock.expectOne('/api/users');
  expect(req.request.method).toBe('GET');
  req.flush(mockUsers);
});
```

### 2. POST Request
```typescript
it('deve criar usuário', (done) => {
  const newUser = { name: 'Pedro' };
  const createdUser = { id: 3, name: 'Pedro' };

  service.createUser(newUser).subscribe(user => {
    expect(user).toEqual(createdUser);
    done();
  });

  const req = httpMock.expectOne('/api/users');
  expect(req.request.method).toBe('POST');
  expect(req.request.body).toEqual(newUser);
  req.flush(createdUser);
});
```

### 3. PUT Request
```typescript
it('deve atualizar usuário', (done) => {
  const userId = 1;
  const updateData = { name: 'João Atualizado' };
  const updatedUser = { id: 1, name: 'João Atualizado' };

  service.updateUser(userId, updateData).subscribe(user => {
    expect(user).toEqual(updatedUser);
    done();
  });

  const req = httpMock.expectOne(`/api/users/${userId}`);
  expect(req.request.method).toBe('PUT');
  expect(req.request.body).toEqual(updateData);
  req.flush(updatedUser);
});
```

### 4. DELETE Request
```typescript
it('deve deletar usuário', (done) => {
  const userId = 1;

  service.deleteUser(userId).subscribe(() => {
    expect(true).toBe(true); // Se chegou aqui, sucesso
    done();
  });

  const req = httpMock.expectOne(`/api/users/${userId}`);
  expect(req.request.method).toBe('DELETE');
  req.flush(null);
});
```

### 5. Request com Parâmetros
```typescript
it('deve buscar com parâmetros', (done) => {
  const params = { page: 1, limit: 10 };
  const mockResponse = { users: [], total: 0 };

  service.getUsersWithParams(params).subscribe(response => {
    expect(response).toEqual(mockResponse);
    done();
  });

  const req = httpMock.expectOne('/api/users?page=1&limit=10');
  expect(req.request.method).toBe('GET');
  req.flush(mockResponse);
});
```

### 6. Request com Headers
```typescript
it('deve enviar headers customizados', (done) => {
  const mockResponse = { data: 'test' };

  service.getWithHeaders().subscribe(response => {
    expect(response).toEqual(mockResponse);
    done();
  });

  const req = httpMock.expectOne('/api/data');
  expect(req.request.headers.get('Authorization')).toBe('Bearer token');
  expect(req.request.headers.get('Content-Type')).toBe('application/json');
  req.flush(mockResponse);
});
```

## ❌ Tratamento de Erros

### 1. Erro HTTP
```typescript
it('deve tratar erro 404', (done) => {
  service.getUser(999).subscribe({
    next: () => fail('Deveria ter falhado'),
    error: (error) => {
      expect(error.status).toBe(404);
      done();
    }
  });

  const req = httpMock.expectOne('/api/users/999');
  req.flush('Not Found', { status: 404, statusText: 'Not Found' });
});
```

### 2. Erro de Rede
```typescript
it('deve tratar erro de rede', (done) => {
  service.getData().subscribe({
    next: () => fail('Deveria ter falhado'),
    error: (error) => {
      expect(error).toBeDefined();
      done();
    }
  });

  const req = httpMock.expectOne('/api/data');
  req.error(new ErrorEvent('Network error'));
});
```

### 3. Timeout
```typescript
it('deve tratar timeout', (done) => {
  service.getDataWithTimeout().subscribe({
    next: () => fail('Deveria ter falhado'),
    error: (error) => {
      expect(error.name).toBe('TimeoutError');
      done();
    }
  });

  const req = httpMock.expectOne('/api/data');
  req.flush(null, { status: 408, statusText: 'Request Timeout' });
});
```

## 🚀 Testes Avançados

### 1. Múltiplas Requisições
```typescript
it('deve fazer múltiplas requisições', (done) => {
  let completed = 0;
  const totalRequests = 2;

  service.getUsers().subscribe(() => {
    completed++;
    if (completed === totalRequests) done();
  });

  service.getPosts().subscribe(() => {
    completed++;
    if (completed === totalRequests) done();
  });

  const req1 = httpMock.expectOne('/api/users');
  const req2 = httpMock.expectOne('/api/posts');
  
  req1.flush([]);
  req2.flush([]);
});
```

### 2. Upload de Arquivo
```typescript
it('deve fazer upload de arquivo', (done) => {
  const file = new File(['content'], 'test.txt', { type: 'text/plain' });
  const mockResponse = { url: 'https://example.com/file.txt' };

  service.uploadFile(file).subscribe(response => {
    expect(response).toEqual(mockResponse);
    done();
  });

  const req = httpMock.expectOne('/api/upload');
  expect(req.request.body).toBeInstanceOf(FormData);
  req.flush(mockResponse);
});
```

### 3. Download de Arquivo
```typescript
it('deve fazer download de arquivo', (done) => {
  const mockBlob = new Blob(['content'], { type: 'text/plain' });

  service.downloadFile().subscribe(blob => {
    expect(blob).toBeInstanceOf(Blob);
    done();
  });

  const req = httpMock.expectOne('/api/download');
  expect(req.request.responseType).toBe('blob');
  req.flush(mockBlob);
});
```

### 4. Interceptors
```typescript
it('deve testar com interceptor', (done) => {
  const mockResponse = { data: 'test' };

  service.getData().subscribe(response => {
    expect(response).toEqual(mockResponse);
    done();
  });

  const req = httpMock.expectOne('/api/data');
  // Verifica se o interceptor adicionou headers
  expect(req.request.headers.get('X-Custom-Header')).toBe('value');
  req.flush(mockResponse);
});
```

## ✅ Boas Práticas

### 1. Sempre use `afterEach`
```typescript
afterEach(() => {
  httpMock.verify(); // Garante que todas as requisições foram feitas
});
```

### 2. Teste tanto sucesso quanto erro
```typescript
describe('getData', () => {
  it('deve retornar dados em caso de sucesso', (done) => {
    // Teste de sucesso
  });

  it('deve tratar erro adequadamente', (done) => {
    // Teste de erro
  });
});
```

### 3. Use `done` para testes assíncronos
```typescript
it('deve fazer requisição assíncrona', (done) => {
  service.getData().subscribe(() => {
    expect(true).toBe(true);
    done(); // Importante!
  });

  const req = httpMock.expectOne('/api/data');
  req.flush({ data: 'test' });
});
```

### 4. Verifique headers e parâmetros
```typescript
const req = httpMock.expectOne('/api/data');
expect(req.request.method).toBe('GET');
expect(req.request.headers.get('Authorization')).toBe('Bearer token');
expect(req.request.params.get('page')).toBe('1');
```

### 5. Use mocks realistas
```typescript
const mockUser = {
  id: 1,
  name: 'João Silva',
  email: 'joao@example.com',
  createdAt: new Date('2023-01-01')
};
```

### 6. Teste edge cases
```typescript
it('deve tratar array vazio', (done) => {
  service.getUsers().subscribe(users => {
    expect(users).toEqual([]);
    done();
  });

  const req = httpMock.expectOne('/api/users');
  req.flush([]);
});

it('deve tratar resposta null', (done) => {
  service.getData().subscribe(data => {
    expect(data).toBeNull();
    done();
  });

  const req = httpMock.expectOne('/api/data');
  req.flush(null);
});
```

## 🎯 Exemplo Completo

```typescript
import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { HttpErrorResponse } from '@angular/common/http';
import { UserService } from './user.service';

describe('UserService', () => {
  let service: UserService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [UserService]
    });

    service = TestBed.inject(UserService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  describe('getUsers', () => {
    it('deve retornar lista de usuários', (done) => {
      const mockUsers = [
        { id: 1, name: 'João', email: 'joao@test.com' },
        { id: 2, name: 'Maria', email: 'maria@test.com' }
      ];

      service.getUsers().subscribe(users => {
        expect(users).toEqual(mockUsers);
        expect(users).toHaveLength(2);
        done();
      });

      const req = httpMock.expectOne('/api/users');
      expect(req.request.method).toBe('GET');
      req.flush(mockUsers);
    });

    it('deve tratar erro 500', (done) => {
      service.getUsers().subscribe({
        next: () => fail('Deveria ter falhado'),
        error: (error) => {
          expect(error.status).toBe(500);
          done();
        }
      });

      const req = httpMock.expectOne('/api/users');
      req.flush('Server Error', { 
        status: 500, 
        statusText: 'Internal Server Error' 
      });
    });
  });

  describe('createUser', () => {
    it('deve criar usuário com sucesso', (done) => {
      const newUser = { name: 'Pedro', email: 'pedro@test.com' };
      const createdUser = { id: 3, ...newUser };

      service.createUser(newUser).subscribe(user => {
        expect(user).toEqual(createdUser);
        done();
      });

      const req = httpMock.expectOne('/api/users');
      expect(req.request.method).toBe('POST');
      expect(req.request.body).toEqual(newUser);
      req.flush(createdUser);
    });
  });
});
```

## 🏆 Conclusão

- **Use `HttpTestingController`** para testes mais robustos
- **Sempre verifique** método, URL, headers e body
- **Teste tanto sucesso quanto erro**
- **Use `done()` para testes assíncronos**
- **Verifique se não há requests pendentes** com `httpMock.verify()`
- **Use mocks realistas** e dados consistentes

Com essas práticas, seus testes de HttpClient serão confiáveis e abrangentes! 🚀
