import { Component, signal, computed, input, output } from '@angular/core';
import { CommonModule } from '@angular/common';

interface User {
  id: number;
  name: string;
  email: string;
}

@Component({
  selector: 'app-user-profile',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="user-profile">
      @if (user()) {
        <h2>{{ user()?.name }}</h2>
        <p>{{ user()?.email }}</p>
        <p>Visits: {{ visitCount() }}</p>
        <p>Status: {{ userStatus() }}</p>
        <button (click)="incrementVisits()">Visit</button>
      } @else {
        <p>Loading user...</p>
      }
    </div>
  `,
  styles: [`
    .user-profile {
      padding: 20px;
      border: 1px solid #ddd;
      border-radius: 8px;
      margin: 20px;
    }
    
    h2 {
      color: #333;
      margin-bottom: 10px;
    }
    
    button {
      background: #667eea;
      color: white;
      border: none;
      padding: 10px 20px;
      border-radius: 5px;
      cursor: pointer;
      margin-top: 10px;
    }
    
    button:hover {
      background: #5568d3;
    }
  `]
})
export class UserProfileComponent {
  // Input com signals (Angular 17)
  userId = input.required<number>();
  
  // Output com signals (Angular 17)
  userLoaded = output<User>();
  visitIncremented = output<number>();
  
  // Signals
  user = signal<User | null>(null);
  visitCount = signal(0);
  
  // Computed signals
  userStatus = computed(() => {
    const count = this.visitCount();
    if (count === 0) return 'New';
    if (count < 5) return 'Regular';
    return 'Frequent';
  });
  
  isActive = computed(() => this.user() !== null);
  
  constructor() {
    // Simula carregamento de dados
    this.loadUser();
  }
  
  private loadUser(): void {
    setTimeout(() => {
      const userData: User = {
        id: this.userId(),
        name: 'John Doe',
        email: 'john@example.com'
      };
      
      this.user.set(userData);
      this.userLoaded.emit(userData);
    }, 100);
  }
  
  incrementVisits(): void {
    this.visitCount.update(count => count + 1);
    this.visitIncremented.emit(this.visitCount());
  }
  
  resetVisits(): void {
    this.visitCount.set(0);
  }
  
  updateUser(updates: Partial<User>): void {
    const currentUser = this.user();
    if (currentUser) {
      this.user.set({ ...currentUser, ...updates });
    }
  }
}

