import { Component, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-counter',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="counter">
      <h2>Counter App</h2>
      <div class="display">
        <p>Count: {{ count() }}</p>
        <p>Double: {{ doubleCount() }}</p>
        <p>Status: {{ status() }}</p>
      </div>
      <div class="controls">
        <button (click)="increment()" class="btn-primary">Increment</button>
        <button (click)="decrement()" class="btn-secondary">Decrement</button>
        <button (click)="reset()" class="btn-danger">Reset</button>
      </div>
      @if (count() > 10) {
        <div class="alert">Count is high!</div>
      }
    </div>
  `,
  styles: [`
    .counter {
      max-width: 400px;
      margin: 20px auto;
      padding: 30px;
      border: 2px solid #667eea;
      border-radius: 10px;
      text-align: center;
    }
    
    h2 {
      color: #667eea;
      margin-bottom: 20px;
    }
    
    .display {
      background: #f8f9fa;
      padding: 20px;
      border-radius: 8px;
      margin-bottom: 20px;
    }
    
    .display p {
      margin: 10px 0;
      font-size: 18px;
    }
    
    .controls {
      display: flex;
      gap: 10px;
      justify-content: center;
      margin-bottom: 15px;
    }
    
    button {
      padding: 10px 20px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-weight: bold;
      transition: all 0.3s;
    }
    
    .btn-primary {
      background: #667eea;
      color: white;
    }
    
    .btn-primary:hover {
      background: #5568d3;
    }
    
    .btn-secondary {
      background: #6c757d;
      color: white;
    }
    
    .btn-secondary:hover {
      background: #5a6268;
    }
    
    .btn-danger {
      background: #dc3545;
      color: white;
    }
    
    .btn-danger:hover {
      background: #c82333;
    }
    
    .alert {
      background: #fff3cd;
      color: #856404;
      padding: 10px;
      border-radius: 5px;
      margin-top: 15px;
    }
  `]
})
export class CounterComponent {
  // Signals
  count = signal(0);
  
  // Computed signals
  doubleCount = computed(() => this.count() * 2);
  
  status = computed(() => {
    const value = this.count();
    if (value === 0) return 'Zero';
    if (value > 0) return 'Positive';
    return 'Negative';
  });
  
  isHighValue = computed(() => this.count() > 10);
  
  // Methods
  increment(): void {
    this.count.update(v => v + 1);
  }
  
  decrement(): void {
    this.count.update(v => v - 1);
  }
  
  reset(): void {
    this.count.set(0);
  }
  
  setCount(value: number): void {
    this.count.set(value);
  }
  
  incrementBy(amount: number): void {
    this.count.update(v => v + amount);
  }
}

