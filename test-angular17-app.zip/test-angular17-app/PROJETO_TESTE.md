# 🎉 Projeto Angular 17 com Jest Test Generator

Este projeto foi criado para demonstrar o uso do **Angular Jest Test Generator** com Angular 17+.

## ✅ O que foi instalado:

### 1. Projeto Angular 17
- ✅ Standalone Components
- ✅ Routing habilitado
- ✅ SCSS para estilos
- ✅ Signals e Control Flow

### 2. Jest Test Framework
- ✅ Jest 29.7.0
- ✅ jest-preset-angular 14.2.2
- ✅ Configuração completa

### 3. Angular Jest Test Generator
- ✅ Instalado do caminho local
- ✅ Scripts configurados
- ✅ Pronto para usar

## 📊 Resultados dos Testes

```
Test Suites: 2 passed, 2 total
Tests:       23 passed, 23 total
Coverage:    60.97% (statements)
```

## 📝 Componentes Criados

### 1. AppComponent (Padrão Angular)
- Componente principal standalone
- Teste gerado automaticamente
- 3 testes passando

### 2. UserProfileComponent (Angular 17 Features)
- ✅ Signals (`signal`, `computed`)
- ✅ Input/Output modernos (`input()`, `output()`)
- ✅ Control Flow (`@if`)
- ✅ Standalone Component
- 20 testes gerados automaticamente

## 🚀 Comandos Disponíveis

### Executar Testes

```bash
# Rodar todos os testes
npm test

# Watch mode
npm run test:watch

# Com coverage
npm run test:coverage
```

### Gerar Novos Testes

```bash
# Gerar teste para um arquivo
npm run generate:test src/app/novo-componente.ts

# Ou usar diretamente
node ../angular-jest-test-generator/index.js src/app/novo-componente.ts

# Gerar testes para todos os arquivos
node ../angular-jest-test-generator/index.js src/app --all
```

## 📁 Estrutura do Projeto

```
test-angular17-app/
├── src/
│   └── app/
│       ├── app.component.ts ..................... ✅ Testado
│       ├── app.component.spec.ts
│       ├── user-profile.component.ts ............ ✅ Testado (Angular 17)
│       └── user-profile.component.spec.ts
├── jest.config.js .............................. ✅ Configurado
├── setup-jest.ts ............................... ✅ Configurado
├── tsconfig.spec.json .......................... ✅ Atualizado para Jest
└── package.json ................................ ✅ Scripts adicionados
```

## 🎯 Exemplo de Uso

### Criar Novo Componente e Gerar Teste

```bash
# 1. Criar componente Angular 17 com signals
cat > src/app/counter.component.ts << 'EOF'
import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-counter',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div>
      <h2>Counter: {{ count() }}</h2>
      <button (click)="increment()">+</button>
      <button (click)="decrement()">-</button>
    </div>
  `
})
export class CounterComponent {
  count = signal(0);
  
  increment() {
    this.count.update(v => v + 1);
  }
  
  decrement() {
    this.count.update(v => v - 1);
  }
}
EOF

# 2. Gerar teste automaticamente
node ../angular-jest-test-generator/index.js src/app/counter.component.ts

# 3. Executar testes
npm test
```

## 💡 Features Angular 17 Demonstradas

### 1. Signals

```typescript
// Signal básico
count = signal(0);

// Computed signal
doubleCount = computed(() => this.count() * 2);

// Update com função
this.count.update(v => v + 1);
```

### 2. Input/Output Modernos

```typescript
// Input required com signal
userId = input.required<number>();

// Output com signal
userLoaded = output<User>();
```

### 3. Control Flow

```typescript
@if (user()) {
  <div>{{ user()?.name }}</div>
} @else {
  <p>Loading...</p>
}
```

## 📊 Cobertura de Testes

| Arquivo | Statements | Branches | Functions | Lines |
|---------|-----------|----------|-----------|-------|
| app.component.ts | 100% | 100% | 100% | 100% |
| user-profile.component.ts | 63.33% | 0% | 66.66% | 68% |

> 💡 **Dica:** Customize os testes gerados para aumentar a cobertura!

## 🎓 Aprendizado

Este projeto demonstra:

1. ✅ **Compatibilidade** - Angular 17 funciona perfeitamente com Jest
2. ✅ **Automação** - Testes gerados em segundos
3. ✅ **Qualidade** - 23 testes rodando sem erros
4. ✅ **Produtividade** - Foco em lógica, não em boilerplate

## 🔧 Próximos Passos

1. **Customize os testes gerados** para casos específicos
2. **Adicione mais componentes** e gere testes automaticamente
3. **Aumente a cobertura** adicionando casos edge
4. **Integre com CI/CD** para executar testes automaticamente

## 📚 Documentação

- [Angular Jest Test Generator](../angular-jest-test-generator/README.md)
- [Compatibilidade Angular 17](../angular-jest-test-generator/COMPATIBILITY.md)
- [Dashboard](../angular-jest-test-generator/scripts/DASHBOARD.md)
- [Exemplos Angular 17](../angular-jest-test-generator/examples/ANGULAR17_EXAMPLES.md)

## 🆘 Problemas?

### Testes não passam?

```bash
# Limpar e reinstalar
rm -rf node_modules package-lock.json
npm install --legacy-peer-deps
npm test
```

### Gerar novos testes?

```bash
# Use o caminho completo do gerador
node /Users/marcio/Development/AAG/angular-jest-test-generator/index.js src/app/seu-arquivo.ts
```

### Ver output detalhado?

```bash
npm test -- --verbose
```

## 🎉 Sucesso!

Projeto criado com:
- ✅ Angular 17+
- ✅ Jest configurado
- ✅ 2 componentes com testes
- ✅ 23 testes passando
- ✅ Coverage habilitado
- ✅ Pronto para desenvolvimento!

---

**💜 Criado com Angular Jest Test Generator**

**📅 Data:** $(date +"%Y-%m-%d %H:%M")
**📍 Local:** /Users/marcio/Development/AAG/test-angular17-app

